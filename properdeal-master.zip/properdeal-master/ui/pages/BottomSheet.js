// BottomSheet.js
import React, { useContext } from 'react';
import { View, Text, Button, StyleSheet, Modal, TouchableOpacity } from 'react-native';
import { AppContext } from '../../context/AppContext';

const BottomSheet = () => {
  const { isBottomSheetVisible, toggleBottomSheet } = useContext(AppContext);

  return (
    <Modal transparent={true} visible={isBottomSheetVisible} animationType="slide">
      <TouchableOpacity style={styles.overlay} onPress={toggleBottomSheet} activeOpacity={1}>
        <View style={styles.sheetContainer}>
          <Text style={styles.sheetTitle}>Bottom Sheet Content</Text>
          <Button title="Close" onPress={toggleBottomSheet} />
        </View>
      </TouchableOpacity>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
    marginBottom: 60 
  },
  sheetContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  sheetTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
});

export default BottomSheet;
