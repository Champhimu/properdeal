export default [
    {
        name:'Dashboard',
        iconType:'Material',
        iconName:'view-dashboard-outline'
    },
    {
        name:'Profile',
        iconType:'Material',
        iconName:'account'
    },
    {
        name:'Settings',
        iconType:'Feather',
        iconName:'settings'
    },
    {
        name:'Saved Items',
        iconType:'Material',
        iconName:'bookmark-check-outline'
    },
    {
        name:'Refer a Friend!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refer a Friends!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refer a Friendss!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refer a Friendsss!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refer a Friendssss!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refer a Friendsssss!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refer as Friend!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refer ass Friend!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refer asss Friend!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refer assss Friend!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refer asssss Friend!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refers a Friends!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refers a Friendss!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refers a Friendsss!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refers a Friendssss!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    },
    {
        name:'Refers a Friendsssss!',
        iconType:'FontAwesome5',
        iconName:'user-friends'
    }
 ]