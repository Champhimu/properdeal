// AppContext.js
import React, { createContext, useState } from 'react';

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [isBottomSheetVisible, setBottomSheetVisible] = useState(false);

  const toggleBottomSheet = () => {
    setBottomSheetVisible(prev => !prev);
  };

  return (
    <AppContext.Provider value={{ isBottomSheetVisible, toggleBottomSheet }}>
      {children}
    </AppContext.Provider>
  );
};
